package Leetcode_268_MissingNumber;

public class MissingNumber {
//list
}
